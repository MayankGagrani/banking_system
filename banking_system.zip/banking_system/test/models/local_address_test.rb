require 'test_helper'

class LocalAddressTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
