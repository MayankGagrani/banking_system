require 'test_helper'

class BeneficieryAccountTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
