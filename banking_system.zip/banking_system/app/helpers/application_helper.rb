module ApplicationHelper

	
end
