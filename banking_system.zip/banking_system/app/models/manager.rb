class Manager < ApplicationRecord
end
