class LocalAddress < ApplicationRecord
	belongs_to :user
	
end
