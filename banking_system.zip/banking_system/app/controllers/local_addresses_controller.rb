class LocalAddressesController < ApplicationController

	
end
