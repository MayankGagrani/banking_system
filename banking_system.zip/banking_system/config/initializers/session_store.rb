# Be sure to restart your server when you modify this file.

BankingSystem::Application.config.session_store :cookie_store, key: '_banking_system_session'
